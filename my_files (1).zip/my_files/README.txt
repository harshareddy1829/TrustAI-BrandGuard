Put your files in this folder. Send them to Claude in chat and they will be saved here.
